package com.common_avro_schemas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonAvroSchemasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonAvroSchemasApplication.class, args);
	}

}
