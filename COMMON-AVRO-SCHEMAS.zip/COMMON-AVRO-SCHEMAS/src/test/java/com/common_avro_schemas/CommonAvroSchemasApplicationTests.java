package com.common_avro_schemas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonAvroSchemasApplicationTests {

	@Test
	void contextLoads() {
	}

}
